### Host Tags Details
|Host Name|Tag|
|---|---|
| DESKTOP-IIQVPJ7 | environment:production1234,<br>environment:production1354,<br>env:prod,<br>source:my_apps,<br>region:west,<br>test:123 |
