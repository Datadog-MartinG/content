### Metric Metadata Details
|Metric Name|Short Name|Type|
|---|---|---|
| datadog.agent.python.version | py version | gauge |
