### Host Tags Details
|Host Name|Tag|
|---|---|
| DESKTOP-IIQVPJ7 | test:123,<br>env:prod,<br>environment:production12,<br>environment:production13,<br>region:east,<br>source:my_apps |
