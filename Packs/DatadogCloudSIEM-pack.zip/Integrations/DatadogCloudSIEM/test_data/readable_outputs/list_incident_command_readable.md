### Incidents List
|ID|Title|Created|Customer Impacted|Customer Impact Duration|Customer Impact Scope|Customer Impact Start|Detected|Resolved|Time to Detect|Time to Internal Response|Time to Repair|Time to Resolve|Severity|State|Detection Method|Root Cause|Summary|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| e0891e96-8084-5c83-9568-1fd41c002bb5 | test-incident | January 25, 2023 07:54 AM | True | 1789225 | scope | April 03, 2023 08:19 AM | January 25, 2023 07:54 AM | None | 0 | 0 | 0 | 0 | UNKNOWN | active | unknown | None | None |
| 1cc7af96-aad6-5085-aa3b-2d121b923642 | test-incident-i1 | January 25, 2023 10:39 AM | False | 0 |  |  | January 25, 2023 10:39 AM | None | 0 | 0 | 0 | 0 | UNKNOWN | resolved | unknown | None | None |
