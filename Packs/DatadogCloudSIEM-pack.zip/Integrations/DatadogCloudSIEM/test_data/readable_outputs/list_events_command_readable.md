### Events List
|Title|Text|Date Happened|Id|Priority|Source|Tags|Is Aggregate|Host|Alert Type|
|---|---|---|---|---|---|---|---|---|---|
| Event Title | Event Text | April 12, 2023 07:03 PM | 6997221848150882000 | normal | dotnet | env:prod,environment:production12,environment:production13,region:east,source:dotnet,source:my_apps,test:123 | false | DESKTOP-IIQVPJ7 | info |
| Event Title | Event Text | April 12, 2023 07:03 PM | 6997221728775245000 | normal | dotnet | env:prod,environment:production12,environment:production13,region:east,source:dotnet,source:my_apps,test:123 | false | DESKTOP-IIQVPJ7 | info |
