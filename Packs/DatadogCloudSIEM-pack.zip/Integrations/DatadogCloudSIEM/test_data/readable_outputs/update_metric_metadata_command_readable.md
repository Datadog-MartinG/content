### Metric Metadata Details
|Metric Name|Description|Short Name|StatusD Interval|Type|
|---|---|---|---|---|
| datadog.agent.python.version | description | python | 60 | gauge |
