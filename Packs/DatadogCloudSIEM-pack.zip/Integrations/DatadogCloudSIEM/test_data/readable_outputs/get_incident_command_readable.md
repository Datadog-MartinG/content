### Incident Details
|ID|Title|Created|Customer Impacted|Customer Impact Duration|Customer Impact Scope|Customer Impact Start|Customer Impact End|Detected|Resolved|Time to Detect|Time to Internal Response|Time to Repair|Time to Resolve|Severity|State|Detection Method|Root Cause|Summary|Notification Display Name|Notification Handle|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 37ad8b5b-b251-5d46-9978-2edbdac3cdb1 | updated title | April 13, 2023 03:27 PM | True | 86400 | impact scope | April 12, 2023 03:56 PM | April 13, 2023 03:56 PM | April 13, 2023 03:56 PM | None | 86400 | 1740 | 0 | 0 | SEV-2 | active | monitor | the root cause | summary text | datadog | abc@domain.com |
